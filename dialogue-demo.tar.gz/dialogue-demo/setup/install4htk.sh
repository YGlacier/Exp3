#!/bin/bash

sudo apt-get install libstdc++6:i386
