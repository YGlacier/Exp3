#!/bin/bash

julius -C asr/grammar-mic.jconf | ./asr-output.pl 
